package roadgraph;

import geography.GeographicPoint;

public class Vertex {
	// Property location: the latitude and longitude of the vertex on the map
	GeographicPoint location;
	public Vertex (GeographicPoint location)
	{
		this.location = location;
	}

}
