package roadgraph;

import geography.GeographicPoint;

public class Vertex {
	GeographicPoint location;
	public Vertex (GeographicPoint location)
	{
		this.location = location;
	}

}
